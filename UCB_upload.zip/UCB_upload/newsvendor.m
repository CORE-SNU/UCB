clear

n = 2;
m = n;
I_m = eye(m);
C = [ eye(m); -eye(m) ];
N = 1e1;
N_simu = 1e3;
n_eva = 1e5;

xi_l1 = 0; xi_u1 = 100;
xi_l2 = 0; xi_u2 = 120;
xi_l = [ xi_l1; xi_l2 ];
xi_u = [ xi_u1; xi_u2 ];
cap = 0.8 * sum(xi_u);

cost = [ 3; 6 ];
price1 = 5;
price2 = 10;
price = [ price1; price2 ];
penalty1 = 2;
penalty2 = 6;
penalty = [ penalty1; penalty2 ]; 
new_mat_x = [ 
    penalty1 penalty2;
    penalty1 -price2;
    -price1 penalty2;
    -price1 -price2 ]; 
new_mat_xi = [
    price1+penalty1 price2+penalty2;
    price1+penalty1 0;
    0 price2+penalty2;
    0 0 ];

prob_set = 0.05:0.05:0.95; 
n_eps = size(prob_set,2);

% DROa
epsilon_set_DROa = norm(xi_u-xi_l,1) * sqrt((2/N) * log(1./(1-prob_set)));
% DROb
if 1 < m/2
    C_star = sqrt(m*2^(m - 2)) * (2 + 1/(1-2^(1 - 0.5*m)));
    epsilon_set_DROb = norm(xi_u-xi_l,inf) * ( C_star*N^(-1/m) + sqrt(2*m*log( 1./(1-prob_set) )/N) );
else
    C_star = sqrt(3 * 2) * (2 + 1/(1-2^(1-0.5*(3))));
    epsilon_set_DROb = norm(xi_u-xi_l,inf) * ( C_star*N^(-1/3) + sqrt(2*3*log( 1./(1-prob_set) )/N) );
end
% DROc
alpha_LCX = 1 - prob_set; 
Q_LCX = norm(xi_u,2)^2;
p_LCX =  0.5 * ( sqrt( log(256) + 8*log(N) + (log(2*N))^2) - log(2*N) ); 
critic_set = (1 + Q_LCX) * (2/(2-p_LCX)) * ((2^(1/2 + 1/p_LCX))/(N^(1 - 1/p_LCX))) * sqrt(m + 1 + (m+1) * log(N/(m+1)) + log(4./alpha_LCX));
% Prop.
beta_set = -0.5*log(1-prob_set);

ucb_DROa = zeros(N_simu,n_eps);
ucb_DROb = zeros(N_simu,n_eps);
ucb_DROc = zeros(N_simu,n_eps);
ucb_pro = zeros(N_simu,n_eps);

sol_DROa = cell(n_eps,1);
sol_DROb = cell(n_eps,1);
sol_DROc = cell(n_eps,1);
sol_pro = cell(n_eps,1);
sol_SAA = zeros(N_simu,m);

R_pro = zeros(N_simu,n_eps);
u_pro = zeros(N_simu,n_eps);
l_pro = zeros(N_simu,n_eps);

loss_DROa = cell(n_eps,1);
loss_DROb = cell(n_eps,1);
loss_DROc = cell(n_eps,1);
loss_pro = cell(n_eps,1);
loss_SAA = zeros(N_simu,n_eva);

exp_DROa = zeros(N_simu,n_eps);    
exp_DROb = zeros(N_simu,n_eps);    
exp_DROc = zeros(N_simu,n_eps);
exp_pro = zeros(N_simu,n_eps);
exp_SAA = zeros(N_simu,1);

for i_eps = 1 : n_eps
    sol_DROa{i_eps} = zeros(N_simu,m);
    sol_DROb{i_eps} = zeros(N_simu,m);
    sol_DROc{i_eps} = zeros(N_simu,m);
    sol_pro{i_eps} = zeros(N_simu,m);

    loss_DROa{i_eps} = zeros(N_simu, n_eva);
    loss_DROb{i_eps} = zeros(N_simu, n_eva);
    loss_DROc{i_eps} = zeros(N_simu, n_eva);
    loss_pro{i_eps} = zeros(N_simu, n_eva);
end

% distribution 
t = cell(m,1);
pd = cell(m,1);
for j = 1 : m
    t{j} = makedist('gamma','a',1.5*j,'b',20*j);
    pd{j} = truncate(t{j},xi_l(j),xi_u(j));
end

sol_RO = xi_l;
obj_RO = cost' * xi_l;

for i_simu = 1 : N_simu
    
    xi_hat_vec = zeros(N*m,1);
    for j = 1 : m
        xi_hat_vec = xi_hat_vec + kron(random(pd{j}, N, 1), I_m(:, j));        
    end
    xi_hat_vec_pro_sol = xi_hat_vec(1:N);
    xi_hat_vec_pro_ucb = xi_hat_vec(N+1:end);
    
    % DROa,b
    K = 4;
    d = [ xi_u; -xi_l ];
    Ain_dum1 = kron( ones(1,N), blkdiag( reshape( kron(ones(N,1),d) - kron(eye(N),C)*xi_hat_vec, size(C,1), []) )' );
    Ain_dum = kron( eye(N), ones(1,size(C,1)) ) .* Ain_dum1;    
    Ain = [
        ones(1,n) zeros(1,1 + N + size(C,1) * N * K);
        kron(new_mat_x,ones(N,1)) zeros(K*N,1) -kron(ones(K,1),eye(N)) kron(eye(K),Ain_dum);
        zeros(K*N*m,n) -ones(K*N*m,1) zeros(N*K*m,N) kron(eye(K),kron(eye(N),C'))
        zeros(K*N*m,n) -ones(K*N*m,1) zeros(N*K*m,N) kron(eye(K),-kron(eye(N),C'))
        ];
    bin = [
        cap
        kron(eye(N),new_mat_xi(1,:)) * xi_hat_vec;
        kron(eye(N),new_mat_xi(2,:)) * xi_hat_vec;
        kron(eye(N),new_mat_xi(3,:)) * xi_hat_vec;
        kron(eye(N),new_mat_xi(4,:)) * xi_hat_vec;
        kron(ones(N,1),-new_mat_xi(1,:)');
        kron(ones(N,1),-new_mat_xi(2,:)');
        kron(ones(N,1),-new_mat_xi(3,:)');
        kron(ones(N,1),-new_mat_xi(4,:)'); 
        -kron(ones(N,1),-new_mat_xi(1,:)');
        -kron(ones(N,1),-new_mat_xi(2,:)');
        -kron(ones(N,1),-new_mat_xi(3,:)');
        -kron(ones(N,1),-new_mat_xi(4,:)');
        ];
    lb = [ zeros(n,1); 0; -inf*ones(N,1); zeros(size(C,1)*N*K,1) ];
    ub = [ xi_u; inf*ones(1+N+size(C,1)*N*K, 1) ];

    % DROa
    for i_eps = 1 : n_eps
        epsilon = epsilon_set_DROa(i_eps);
        f = [ cost; epsilon; 1/N*ones(N,1); zeros(size(C,1)*N*K,1) ];
        [ sol, fval ] = cplexlp(f,Ain,bin,[],[],lb,ub);
        sol_DROa{i_eps}(i_simu,:) = sol(1:n);
        ucb_DROa(i_simu,i_eps) = fval;
    end
    
    % DROb
    for i_eps = 1 : n_eps
        epsilon = epsilon_set_DROb(i_eps);
        f = [ cost; epsilon; 1/N*ones(N,1); zeros(size(C,1)*N*K,1) ];
        [ sol, fval ] = cplexlp(f,Ain,bin,[],[],lb,ub);
        sol_DROb{i_eps}(i_simu,:) = sol(1:n);
        ucb_DROb(i_simu,i_eps) = fval;
    end

    % DROc
    xi_hat_matrix = reshape( xi_hat_vec, m, N )';
    gam_matrix = dec2bin(0:2^K-1)' - '0';
    gam_matrix = gam_matrix(:,2:end);
    num_gam = size(gam_matrix,2);
    size_r = 1;
    size_z = num_gam*N;
    size_y = num_gam*m;
    size_y_prime = num_gam;
    size_w = num_gam*m;
    size_w_prime = num_gam;
    size_f = 1;
    size_g = K;
    size_h = K*m;
    n_var_RSA = n + size_r+size_z+size_y+size_y_prime+size_w+size_w_prime+size_f+size_g+size_h;
    Xi_V = [
        xi_l1 xi_l2;
        xi_u1 xi_u2;
        xi_l1 xi_u2;
        xi_u1 xi_l2
        ];
    size_Xi_V = size(Xi_V,1);
    Ain_RSA = [
        ones(1,n) zeros(1,n_var_RSA - n);
        zeros(K,n) -ones(K,1) zeros(K,size_z+size_y+size_y_prime+size_w) gam_matrix zeros(K,size_f) -eye(K) zeros(K,size_h);
        zeros(size_z,n) zeros(size_z,size_r) -eye(size_z) zeros(size_z,size_y+size_y_prime) (1/N)*kron(eye(num_gam),xi_hat_matrix) -(1/N)*kron(eye(num_gam),ones(N,1)) zeros(size_z, size_f+size_g+size_h);
        zeros(size_w,n) zeros(size_w,size_r+size_z) -eye(size_y) zeros(size_y,size_y_prime) eye(size_w) zeros(size_w,size_w_prime+size_g+size_f+size_h);
        zeros(size_w,n) zeros(size_w,size_r+size_z) -eye(size_y) zeros(size_y,size_y_prime) -eye(size_w) zeros(size_w,size_w_prime+size_g+size_f+size_h);
        zeros(size_w_prime,n) zeros(size_w_prime,size_r+size_z+size_y) -eye(size_y_prime) zeros(size_y_prime,size_w) eye(size_w_prime) zeros(size_w_prime,size_g+size_f+size_h);
        zeros(size_w_prime,n) zeros(size_w_prime,size_r+size_z+size_y) -eye(size_y_prime) zeros(size_y_prime,size_w) -eye(size_w_prime) zeros(size_w_prime,size_g+size_f+size_h);
        zeros(size_f,n) zeros(size_f,size_r+size_z) ones(size_f,size_y+size_y_prime) zeros(size_f,size_w+size_w_prime) -1 zeros(size_f,size_g+size_h);
        kron(new_mat_x,ones(size_Xi_V,1)) zeros(size_Xi_V*K,size_r+size_z+size_y+size_y_prime+size_w+size_w_prime+size_f) kron(eye(K),ones(size_Xi_V,1)) -kron(eye(K),Xi_V);
        ];
    bin_RSA_cell_dum = cell(K,1);
    for j = 1 : K
        bin_RSA_cell_dum{j} = kron(eye(size_Xi_V), new_mat_xi(j,:));
    end
    bin_RSA_cell = blkdiag(bin_RSA_cell_dum{:});
    bin_RSA = [
        cap
        zeros(K,1);
        zeros(size_z,1);
        zeros(2*size_w+2*size_w_prime,1);
        0;
        bin_RSA_cell * kron(ones(K,1),reshape(Xi_V',[],1))
        ];
    Aeq_RSA = [
        zeros(size_h, n + size_r+size_z+size_y+size_y_prime) kron(gam_matrix,eye(m)) zeros(size_h,size_w_prime+size_f+size_g) -eye(size_h);
        ];
    beq_RSA = zeros(size_h,1);
    lb_RSA = [
        xi_l;
        -inf*ones(size_r,1);
        0*ones(size_z+size_y+size_y_prime+size_w+size_w_prime+size_f,1);
        -inf*ones(size_g+size_h,1)
        ];
    ub_RSA = [
        xi_u;
        inf*ones(n_var_RSA-n, 1)
        ];

    for i_eps = 1 : n_eps        
        f_RSA = [
            cost;
            1;
            ones(size_z, 1);
            zeros(size_y, 1);
            zeros(size_y_prime, 1);
            zeros(size_w, 1);
            zeros(size_w_prime, 1);
            critic_set(i_eps);
            zeros(size_g, 1);
            zeros(size_h, 1)
            ];
        [ sol, fval ] = cplexlp(f_RSA,Ain_RSA,bin_RSA,Aeq_RSA,beq_RSA,lb_RSA,ub_RSA);
        sol_DROc{i_eps}(i_simu,:) = sol(1:n);
        ucb_DROc(i_simu,i_eps) = fval;
    end
    
    % Prop.
    lb = [ zeros(n, 1); -inf*ones(N/2 + 2, 1) ];
    ub = [ xi_u; inf*ones(N/2 + 2, 1) ];
    for i_eps = 1 : n_eps
        beta_pro = beta_set(i_eps);
        f = [ cost; 2/N*ones(N/2,1); sqrt(2*beta_pro/N); sqrt(2*beta_pro/N) ]; 
        sol = zeros(n + N/2 + 2, K);
        fval = zeros(K,1);
        for k = 1 : K
            Ain = [
                ones(1,n) zeros(1,N/2 + 2);
                kron(ones(N/2,1),new_mat_x) -kron(eye(N/2),ones(K,1)) zeros(N*K/2,2);
                new_mat_x zeros(K,N/2) -ones(K,1) zeros(K,1);
                -new_mat_x(k,:) zeros(1,N/2) 0 -1;              
                ];
            bin = [ 
                cap;
                kron(eye(N/2), new_mat_xi) * xi_hat_vec_pro_sol;
                new_mat_xi * xi_l;
                -new_mat_xi(k,:) * xi_u;
                ];
            [ sol(:,k), fval(k) ] = cplexlp(f,Ain,bin,[],[],lb,ub);        
        end 

        [ ~, ind_sol ] = sort(fval,'descend');
        sol_pro_dum = sol(:,ind_sol(end));
        sol_pro{i_eps}(i_simu,:) = sol_pro_dum(1:n);
        
        u_pro(i_simu,i_eps) = cost'*sol_pro{i_eps}(i_simu,:)' + sol_pro_dum(n + N/2 + 1);
        l_pro(i_simu,i_eps) = cost'*sol_pro{i_eps}(i_simu,:)' - sol_pro_dum(end);
        R_pro(i_simu,i_eps) = u_pro(i_simu,i_eps) - l_pro(i_simu,i_eps);
        eta = zeros(N/2,1);
        for i_sample = 1 : N/2
            eta(i_sample) = max(new_mat_x * sol_pro{i_eps}(i_simu,:)' - new_mat_xi * xi_hat_vec_pro_ucb(2*i_sample-1 : 2*i_sample));
        end
        ucb_pro(i_simu, i_eps) = cost'*sol_pro{i_eps}(i_simu,:)' + mean(eta) + sqrt(2*beta_pro/N)*R_pro(i_simu,i_eps);
        if ucb_pro(i_simu,i_eps) > obj_RO
            ucb_pro(i_simu,i_eps) = obj_RO;
            sol_pro{i_eps}(i_simu,:) = sol_RO;
        end
    end
    
    % SAA
    lb = [ zeros(n, 1); -inf*ones(N, 1) ];
    ub = [ xi_u; inf*ones(N, 1) ];
    f = [ cost; 1/N*ones(N,1) ]; 
    Ain = [
        ones(1,n) zeros(1,N);
        kron(ones(N,1),new_mat_x) -kron(eye(N),ones(K,1));
        ];
    bin = [ 
        cap;
        kron(eye(N), new_mat_xi) * xi_hat_vec;
        ];
    [ sol, ~ ] = cplexlp(f,Ain,bin,[],[],lb,ub);
    sol_SAA(i_simu,:) = sol(1:n);

    % expected cost
    for i_oos = 1 : n_eva
        
        xi_hat_oos_vec = zeros(m,1);
        for j = 1 : m
            xi_hat_oos_vec = xi_hat_oos_vec + kron(random(pd{j}, 1, 1), I_m(:, j));
        end
        
        % DROa
        for i_eps = 1 : n_eps
            loss_DROa{i_eps}(i_simu, i_oos) = cost'*sol_DROa{i_eps}(i_simu,:)' + max(new_mat_x * sol_DROa{i_eps}(i_simu,:)' - new_mat_xi * xi_hat_oos_vec);
        end
        % DROb
        for i_eps = 1 : n_eps
            loss_DROb{i_eps}(i_simu, i_oos) = cost'*sol_DROb{i_eps}(i_simu,:)' + max(new_mat_x * sol_DROb{i_eps}(i_simu,:)' - new_mat_xi * xi_hat_oos_vec);
        end 
        % DROc
        for i_eps = 1 : n_eps
            loss_DROc{i_eps}(i_simu, i_oos) = cost'*sol_DROc{i_eps}(i_simu,:)' + max(new_mat_x * sol_DROc{i_eps}(i_simu,:)' - new_mat_xi * xi_hat_oos_vec);
        end
        % Prop.
        for i_eps = 1 : n_eps
            loss_pro{i_eps}(i_simu, i_oos) = cost'*sol_pro{i_eps}(i_simu,:)' + max(new_mat_x * sol_pro{i_eps}(i_simu,:)' - new_mat_xi * xi_hat_oos_vec);
        end
        % SAA
        loss_SAA(i_simu, i_oos) = cost'*sol_SAA(i_simu,:)' + max(new_mat_x * sol_SAA(i_simu,:)' - new_mat_xi * xi_hat_oos_vec);
    end
   
    for i_eps = 1 : n_eps
        exp_DROa(i_simu,i_eps) = mean(loss_DROa{i_eps}(i_simu,:));    
        exp_DROb(i_simu,i_eps) = mean(loss_DROb{i_eps}(i_simu,:)); 
        exp_DROc(i_simu,i_eps) = mean(loss_DROc{i_eps}(i_simu,:));
        exp_pro(i_simu,i_eps) = mean(loss_pro{i_eps}(i_simu,:));    
    end
    exp_SAA(i_simu) = mean(loss_SAA(i_simu,:));

end

ucb_DROa = mean(ucb_DROa);
ucb_DROb = mean(ucb_DROb);
ucb_DROc = mean(ucb_DROc);
ucb_pro = mean(ucb_pro);

exp_DROa = mean(exp_DROa);
exp_DROb = mean(exp_DROb);
exp_DROc = mean(exp_DROc);
exp_pro = mean(exp_pro);
exp_SAA = mean(exp_SAA);

