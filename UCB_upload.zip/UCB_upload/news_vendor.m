clear

n = 1;
m = n;
N = 1e1; % sample size
N_simu = 1e3;
n_eva = 1e5;
xi_l = 0;
xi_u = 100;
cost = 3;
price = 5;
b = 0;
penalty = 2;

prob_set = .05:.05:.95; % confidence
n_eps = size(prob_set,2);
% DROa
diam_DROa = norm(xi_u - xi_l, 1);
epsilon_set_DROa = diam_DROa * sqrt( (2/N) * log(1./(1-prob_set)) );
% DROb
diam_DROb = norm(xi_u - xi_l, inf);
if 1 < m/2
    C_star = sqrt(m*2^(m - 2)) * (2 + 1/(1-2^(1 - 0.5*m)));
    epsilon_set_DROb = diam_DROb * ( C_star*N^(-1/m) + sqrt(2*m*log( 1./(1-prob_set) )/N) );
else
    C_star = sqrt(3 * 2) * (2 + 1/(1-2^(1-0.5*(3))));
    epsilon_set_DROb = diam_DROb * ( C_star*N^(-1/3) + sqrt(2*3*log( 1./(1-prob_set) )/N) );
end
% DROc
critic_list = zeros(1e5,1);
for i = 1 : size(critic_list,1)
    dum = sort( rand(N,1), 'ascend' );
    critic_list(i) = max( max( [(1:N)'/N-dum dum-(0:N-1)'/N] ) );
end
critic_set = prctile(critic_list, 100 * prob_set);
% Prop.
beta_set = -0.5*log(1-prob_set);

obj_DROa = zeros(N_simu,n_eps);    
obj_DROb = zeros(N_simu,n_eps);    
obj_DROc = zeros(N_simu,n_eps);
obj_pro = zeros(N_simu,n_eps);

sol_DROa = cell(n_eps,1);
sol_DROb = cell(n_eps,1);
sol_DROc = cell(n_eps,1);
sol_pro = cell(n_eps,1);

loss_DROa = cell(n_eps,1);
loss_DROb = cell(n_eps,1);
loss_DROc = cell(n_eps,1);
loss_pro = cell(n_eps,1);

oos_DROa = zeros(N_simu,n_eps);    
oos_DROb = zeros(N_simu,n_eps);    
oos_DROc = zeros(N_simu,n_eps);
oos_pro = zeros(N_simu,n_eps);

for i_eps = 1:n_eps
    
    sol_DROa{i_eps} = zeros(N_simu,m);
    sol_DROb{i_eps} = zeros(N_simu,m);
    sol_DROc{i_eps} = zeros(N_simu,m);
    sol_pro{i_eps} = zeros(N_simu,m);

    loss_DROa{i_eps} = zeros(N_simu, n_eva);
    loss_DROb{i_eps} = zeros(N_simu, n_eva);
    loss_DROc{i_eps} = zeros(N_simu, n_eva);
    loss_pro{i_eps} = zeros(N_simu, n_eva);

end

%% distribution 
t = cell(m,1);
pd = cell(m,1);
for j = 1 : m
    t{j} = makedist('gamma','a',1.5,'b',20);
    pd{j} = truncate(t{j},xi_l(j),xi_u(j));    
end

%% RO
sol_RO = xi_l;
obj_RO = cost' * xi_l;

for i_simu = 1 : N_simu
    
    % Sample
    xi_hat_vec = random(pd{1}, N, 1);    

    %% DROa,b
    K = 2;
    C = [ eye(m); -eye(m) ];
    d = [ xi_u; -xi_l ];
    n_var_DRO = n + 1 + N + size(C,1) * N * K;
    a1 = b;
    a2 = -(penalty + price);
    Ain_dum1 = kron( ones(1,N), blkdiag( reshape( kron(ones(N,1),d) - kron(eye(N),C)*xi_hat_vec, size(C,1), []) )' );
    Ain_dum = kron( eye(N), ones(1,size(C,1)) ) .* Ain_dum1;
    Ain = [
        -kron(ones(N,1),diag(price+b)) zeros(N,1) -eye(N) Ain_dum zeros(N,K*N);
        kron(ones(N,1),diag(penalty)) zeros(N,1) -eye(N) zeros(N,N*K) Ain_dum;
        zeros(N,n) -ones(N,1) zeros(N) kron(eye(N),C') zeros(N,K*N);
        zeros(N,n) -ones(N,1) zeros(N) zeros(N,K*N) kron(eye(N),C');
        zeros(N,n) -ones(N,1) zeros(N) -kron(eye(N),C') zeros(N,K*N);
        zeros(N,n) -ones(N,1) zeros(N) zeros(N,K*N) -kron(eye(N),C')
        ];
    bin = [
        - xi_hat_vec .* kron(ones(N,1),b);
        xi_hat_vec .* kron(ones(N,1),penalty+price);
        a1 * ones(N,1);
        a2 * ones(N,1);
        - a1 * ones(N,1);
        - a2 * ones(N,1)        
        ];
    lb = [ zeros(m,1); 0; -inf*ones(N,1); zeros(size(C,1)*N*K,1) ];
    ub = [ xi_u; inf*ones(1+N+size(C,1)*N*K, 1) ];

    % DROa
    for i_eps = 1 : n_eps
        epsilon = epsilon_set_DROa(i_eps);
        f = [ cost; epsilon; 1/N*ones(N,1); zeros(size(C,1)*N*K,1) ];
        [ sol, fval ] = cplexlp(f,Ain,bin,[],[],lb,ub);
        sol_DROa{i_eps}(i_simu,:) = sol(1:m);
        obj_DROa(i_simu,i_eps) = fval;
    end
    
    % DROb
    for i_eps = 1 : n_eps
        epsilon = epsilon_set_DROb(i_eps);
        f = [ cost; epsilon; 1/N*ones(N,1); zeros(size(C,1)*N*K,1) ];
        [ sol, fval ] = cplexlp(f,Ain,bin,[],[],lb,ub);
        sol_DROb{i_eps}(i_simu,:) = sol(1:m);
        obj_DROb(i_simu,i_eps) = fval;
    end
    
    %% DROc
    xi_hat_ext = [ xi_l; sort(xi_hat_vec,'ascend'); xi_u ];
    lb = [ zeros(m,1); -inf*ones(2*N + N + 1, 1) ];
    ub = [ xi_u; zeros(2*N,1); inf*ones(1 + N, 1) ];
    A_DN = [ eye(N); -eye(N) ];
    Ain = [
        -kron(ones(N+1,1),diag(b+price)) zeros(N+1,size(A_DN',2)) -eye(N+1);
        kron(ones(N+1,1),diag(penalty)) zeros(N+1,size(A_DN',2)) -eye(N+1)
        ];
    bin = [
        -b * [ zeros(N+1,1) eye(N+1) ] * xi_hat_ext;
        (penalty+price) * [ eye(N+1) zeros(N+1,1) ] * xi_hat_ext;
        ];
    Aeq = [
        zeros(size(A_DN',1),n) -A_DN' [ eye(N) zeros(N,1) ]-[ zeros(N,1) eye(N) ];
        ];
    beq = zeros(size(A_DN',1), 1);
    for i_eps = 1 : n_eps
        b_DN = [ (1:N)/N -(0:N-1)/N ]' - critic_set(i_eps);
        f = [ cost; b_DN; zeros(N,1); 1 ];
        [ sol, fval ] = cplexlp(f,Ain,bin,Aeq,beq,lb,ub);
        sol_DROc{i_eps}(i_simu,:) = sol(1:m);
        obj_DROc(i_simu,i_eps) = fval;
    end
    
    %% Prop.
    n_var = n + N*n + 2*n;
    lb = [ zeros(n, 1); -inf*ones(N*n + 2*n, 1) ];
    ub = [ xi_u; inf*ones(N*n+2*n, 1) ];
    for i_eps = 1 : n_eps
        beta_pro = beta_set(i_eps);
        f = [ cost; 1/N*ones(N*n,1); sqrt(beta_pro/N) * ones(n,1); sqrt(beta_pro/N) * ones(n,1) ];             
        sol = zeros(n_var, K);
        fval = zeros(K,1);    
        k = 1;
        Ain = [
            -kron(ones(N,1), diag(price+b)) -eye(N*n) zeros(N*n,n) zeros(N*n,n);
            kron(ones(N,1), diag(penalty)) -eye(N*n) zeros(N*n,n) zeros(N*n,n);
            -diag(price+b) zeros(n,N*n) -eye(n) zeros(n);
            diag(penalty) zeros(n,N*n) -eye(n) zeros(n);
            diag(price+b) zeros(n,N*n) zeros(n,n) -eye(n);
            ];
        bin = [ 
            - xi_hat_vec .* kron(ones(N,1),b); 
            xi_hat_vec .* kron(ones(N,1),price+penalty); 
            -xi_u .* b;
            xi_l .* (penalty+price);
            xi_l .* b;
            ];
        [ sol(:,k), fval(k) ] = cplexlp(f,Ain,bin,[],[],lb,ub);        
        k = 2;
        Ain = [
            -kron(ones(N,1), diag(price + b)) -eye(N*n) zeros(N*n,n) zeros(N*n,n);
            kron(ones(N,1), diag(penalty)) -eye(N*n) zeros(N*n,n) zeros(N*n,n);
            -diag(price + b) zeros(n,N*n) -eye(n) zeros(n);
            diag(penalty) zeros(n,N*n) -eye(n) zeros(n);
            -diag(penalty) zeros(n,N*n) zeros(n) -eye(n)      
            ];
        bin = [
            - xi_hat_vec .* kron(ones(N,1),b); 
            xi_hat_vec .* kron(ones(N,1),price+penalty); 
            -xi_u .* b;
            xi_l .* (penalty+price);
            - xi_u .* (penalty+price)
            ];
        [ sol(:,k), fval(k) ] = cplexlp(f,Ain,bin,[],[],lb,ub);
                
        [ ~, ind_sol ] = sort(fval,'descend');
        sol_pro_dum = sol(:,ind_sol(end));
        sol_pro{i_eps}(i_simu,:) = sol_pro_dum(1:n);
        obj_pro(i_simu,i_eps) = fval(ind_sol(end));
        if obj_pro(i_simu,i_eps) > obj_RO
            obj_pro(i_simu,i_eps) = obj_RO;
            sol_pro{i_eps}(i_simu,:) = sol_RO;
        end
    end

    %% Expected cost
    for i_oos = 1 : n_eva

        % Sample
        xi_hat_oos_vec = random(pd{1}, 1, 1);

        % DROa
        for i_eps = 1 : n_eps
            eta = zeros(n,1);
            for j = 1 : n
                eta(j) = max( ...
                    -(price(j) + b(j))*sol_DROa{i_eps}(i_simu,j) + b(j)*xi_hat_oos_vec(j), ...
                    -(price(j) + penalty(j))*xi_hat_oos_vec(j) + penalty(j)*sol_DROa{i_eps}(i_simu,j));
            end
            loss_DROa{i_eps}(i_simu, i_oos) = cost'*sol_DROa{i_eps}(i_simu,:) + sum(eta);
        end
        % DROb
        for i_eps = 1 : n_eps
            eta = zeros(n,1);
            for j = 1 : n
                eta(j) = max( ...
                    -(price(j) + b(j))*sol_DROb{i_eps}(i_simu,j) + b(j)*xi_hat_oos_vec(j), ...
                    -(price(j) + penalty(j))*xi_hat_oos_vec(j) + penalty(j)*sol_DROb{i_eps}(i_simu,j));
            end
            loss_DROb{i_eps}(i_simu, i_oos) = cost'*sol_DROb{i_eps}(i_simu,:) + sum(eta);
        end        
        % DROc
        for i_eps = 1 : n_eps
            eta = zeros(n,1);
            for j = 1 : n
                eta(j) = max( ...
                    -(price(j) + b(j))*sol_DROc{i_eps}(i_simu,j) + b(j)*xi_hat_oos_vec(j), ...
                    -(price(j) + penalty(j))*xi_hat_oos_vec(j) + penalty(j)*sol_DROc{i_eps}(i_simu,j));
            end
            loss_DROc{i_eps}(i_simu, i_oos) = cost'*sol_DROc{i_eps}(i_simu,:) + sum(eta);
        end        
        % Prop.
        for i_eps = 1 : n_eps
            eta = zeros(n,1);
            for j = 1 : n
                eta(j) = max( ...
                    -(price(j) + b(j))*sol_pro{i_eps}(i_simu,j) + b(j)*xi_hat_oos_vec(j), ...
                    -(price(j) + penalty(j))*xi_hat_oos_vec(j) + penalty(j)*sol_pro{i_eps}(i_simu,j));
            end
            loss_pro{i_eps}(i_simu, i_oos) = cost'*sol_pro{i_eps}(i_simu,:) + sum(eta);
        end

    end
    
    for i_eps = 1 : n_eps
        oos_DROa(i_simu,i_eps) = mean(loss_DROa{i_eps}(i_simu,:));    
        oos_DROb(i_simu,i_eps) = mean(loss_DROb{i_eps}(i_simu,:));    
        oos_DROc(i_simu,i_eps) = mean(loss_DROc{i_eps}(i_simu,:));
        oos_pro(i_simu,i_eps) = mean(loss_pro{i_eps}(i_simu,:));    
    end    
end

optimal_value_DROa = mean(obj_DROa);
optimal_value_DROb = mean(obj_DROb);
optimal_value_DROc = mean(obj_DROc);
optimal_value_pro = mean(obj_pro);

expected_cost_DROa = mean(oos_DROa);
expected_cost_DROb = mean(oos_DROb);
expected_cost_DROc = mean(oos_DROc);
expected_cost_pro = mean(oos_pro);
