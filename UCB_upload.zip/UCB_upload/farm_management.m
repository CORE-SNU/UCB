clear

n = 3;
m = 2;
I_m = eye(m);
C = [ eye(m); -eye(m) ];    
N = 1e1; % sample size
N_simu = 1e3;
n_eva = 1e5;
xi_mu = [ 200; 240 ];
xi_u = 2 * xi_mu;
xi_l = 0 * xi_mu;
d = [ xi_u; -xi_l ];

prob_set = .05:.05:.95; % confidence
n_eps = size(prob_set,2);
% DROa
diam_DROa = norm(xi_u - xi_l, 1);
epsilon_set_DROa = diam_DROa * sqrt( (2/N) * log(1./(1-prob_set)) );
% DROb
diam_DROb = norm(xi_u - xi_l, inf);
if 1 < m/2
    C_star = sqrt(m*2^(m - 2)) * (2 + 1/(1-2^(1 - 0.5*m)));
    epsilon_set_DROb = diam_DROb * ( C_star*N^(-1/m) + sqrt(2*m*log( 1./(1-prob_set) )/N) );
else
    C_star = sqrt(3 * 2) * (2 + 1/(1-2^(1-0.5*(3))));
    epsilon_set_DROb = diam_DROb * ( C_star*N^(-1/3) + sqrt(2*3*log( 1./(1-prob_set) )/N) );
end
% DROc
alpha_LCX = 1 - prob_set; 
Q_LCX = norm(xi_u,2)^2; 
p_LCX =  0.5 * ( sqrt( log(256) + 8*log(N) + (log(2*N))^2) - log(2*N) ); 
critic_set = (1 + Q_LCX) * (2/(2-p_LCX)) * ((2^(1/2 + 1/p_LCX))/(N^(1 - 1/p_LCX))) * sqrt(m + 1 + (m+1) * log(N/(m+1)) + log(4./alpha_LCX));
% Prop.
beta_set = -0.5*log(1-prob_set);

loss_DROa = cell(n_eps,1);
loss_DROb = cell(n_eps,1);
loss_DROc = cell(n_eps,1);
loss_pro = cell(n_eps,1);

obj_DROa = zeros(N_simu,n_eps);    
obj_DROb = zeros(N_simu,n_eps);    
obj_DROc = zeros(N_simu,n_eps);
obj_pro = zeros(N_simu,n_eps);

oos_DROa = zeros(N_simu,n_eps);    
oos_DROb = zeros(N_simu,n_eps);    
oos_DROc = zeros(N_simu,n_eps);    
oos_pro = zeros(N_simu,n_eps);

sol_DROa = cell(n_eps,1);
sol_DROb = cell(n_eps,1);
sol_DROc = cell(n_eps,1);
sol_pro = cell(n_eps,1);

for i_eps = 1:n_eps
    
    sol_DROa{i_eps} = zeros(N_simu,n);
    sol_DROb{i_eps} = zeros(N_simu,n);
    sol_DROc{i_eps} = zeros(N_simu,n);
    sol_pro{i_eps} = zeros(N_simu,n);

    loss_DROa{i_eps} = zeros(N_simu,n_eva);    
    loss_DROb{i_eps} = zeros(N_simu,n_eva);    
    loss_DROc{i_eps} = zeros(N_simu,n_eva);    
    loss_pro{i_eps} = zeros(N_simu,n_eva);
    
end

yield_wheat = 2.5;
yield_corn = 3; 
yield_sugar = 20;
panting_cost_wheat = 150;
panting_cost_corn = 230;
panting_cost_sugar = 260;
cap = 500;

f_dum = [ 238; 210; -170; -150; -36; -10];
A_dum = [
    -1 0 1 0 0 0;
    0 -1 0 1 0 0;
    0 0 0 0 1 1;
    0 0 0 0 1 0
    ];
B_dum = [
    yield_wheat 0 0;
    0 yield_corn 0;
    0 0 yield_sugar;
    0 0 0
    ];
D_dum = [
    -1 0;
    0 -1;
    0 0;
    0 0
    ];
e_dum = [ 0; 0; 0; 6000 ];
Ain_dum = A_dum;

%% distribution 
t = cell(m,1);
pd = cell(m,1);
for j = 1 : m
    t{j} = makedist('Normal','mu',xi_mu(j),'sigma',0.3*xi_mu(j));
    pd{j} = truncate(t{j},xi_l(j),xi_u(j));
end

K = 8;
I_K = eye(K);
lam1 = [ 170; 170; 238; 238; 170; 170; 238; 238 ];
lam2 = [ 150; 210; 150; 210; 150; 210; 150; 210 ];
lam3 = [ 10; 10; 10; 10; 36; 36; 36; 36 ];
lam4 = [ 26; 26; 26; 26; 0; 0; 0; 0 ];
gam_matrix = dec2bin(0:2^K-1)' - '0';
gam_matrix = gam_matrix(:,2:end);
num_gam = size(gam_matrix,2);
size_r = 1;
size_z = num_gam*N;
size_y = num_gam*m;
size_y_prime = num_gam;
size_w = num_gam*m;
size_w_prime = num_gam;
size_f = 1;
size_g = K;
size_h = K*m;
n_var_RSA = m + 1 + size_r+size_z+size_y+size_y_prime+size_w+...
    size_w_prime+size_f+size_g+size_h;
Xi_V = [
    0 0;
    400 480;
    0 480;
    400 480
    ];
size_Xi_V = size(Xi_V,1);

%% RO
f_RO = [ panting_cost_wheat; panting_cost_corn; panting_cost_sugar; 1 ];
lb_RO = [ zeros(3,1); -inf*ones(1,1) ];
Ain_RO = [
    ones(1,3) zeros(1,1);
    -yield_wheat*lam1 -yield_corn*lam2 -yield_sugar*lam3 -ones(K,1);
    ];
bin_RO = [
    cap;
    - xi_u(1) * lam1 - xi_u(2) * lam2 + 6000 * lam4;
    ];
[ sol, obj_RO ] = cplexlp(f_RO,Ain_RO,bin_RO,[],[],lb_RO);
sol_RO = sol(1:n);

for i_simu = 1 : N_simu
    
    % Sample
    xi_hat_vec = zeros(N*m,1);
    for j = 1 : m
        xi_hat_vec = xi_hat_vec + kron(random(pd{j}, N, 1), I_m(:, j));        
    end
    dum = reshape(xi_hat_vec,m,[]);
    xi1_hat_vec = dum(1,:)';
    xi2_hat_vec = dum(2,:)';

    %% DROa,b
    n_var_DRO = n + 1 + N + size(C,1) * N * K;
    
    Aa_konetoK = zeros(K*m,n);
    ba_konetoK = kron(lam1,I_m(:,1)) + kron(lam2,I_m(:,2));
    Ab_konetoK = [ -yield_wheat*lam1 -yield_corn*lam2 -yield_sugar*lam3 ];
    bb_konetoK = -6000*lam4;
    
    A_cell = cell(N,1);
    gamma_cell = cell(N,1);
    for i = 1 : N
        A_cell{i} = kron(I_K, dum(:,i)');
        gamma_cell{i} = kron(I_K, (d - C*dum(:,i))');
    end
    x_dum = kron(ones(N,1),Ab_konetoK) + blkdiag(A_cell{:}) * kron(ones(N,1),Aa_konetoK);
    gamma_dum = blkdiag(gamma_cell{:});
    b_dum = - blkdiag(A_cell{:})*kron(ones(N,1),ba_konetoK) - kron(ones(N,1),bb_konetoK);
    
    Ain = [
        ones(1,n) zeros(1,1 + N + size(C,1)*N*K);
        x_dum zeros(size(x_dum,1),1) -kron(eye(N), ones(K,1)) gamma_dum;
        -kron(ones(N,1), Aa_konetoK) -ones(N*K*size(C',1),1) zeros(N*size(Aa_konetoK,1),N) kron(eye(N*K),C');
        kron(ones(N,1), Aa_konetoK) -ones(N*K*size(C',1),1) zeros(N*size(Aa_konetoK,1),N) -kron(eye(N*K),C')        
        ];
    bin = [
        cap;
        b_dum;
        kron(ones(N,1),ba_konetoK);
        -kron(ones(N,1),ba_konetoK);
        ];
    lb = [ zeros(n,1); 0; -inf*ones(N,1); zeros(size(C,1)*N*K,1) ];
    ub = [ 500*ones(n,1); inf*ones(1+N+size(C,1)*N*K, 1) ];

    % DROa
    for i_eps = 1 : n_eps
        epsilon = epsilon_set_DROa(i_eps);
        f = [ panting_cost_wheat; panting_cost_corn; panting_cost_sugar; epsilon; 1/N*ones(N,1); zeros(size(C,1)*N*K,1) ];
        [ sol, fval ] = cplexlp(f,Ain,bin,[],[],lb,ub);
        sol_DROa{i_eps}(i_simu,:) = sol(1:n);
        obj_DROa(i_simu,i_eps) = fval;
    end

    % DROb
    for i_eps = 1 : n_eps
        epsilon = epsilon_set_DROb(i_eps);
        f = [ panting_cost_wheat; panting_cost_corn; panting_cost_sugar; epsilon; 1/N*ones(N,1); zeros(size(C,1)*N*K,1) ];
        [ sol, fval ] = cplexlp(f,Ain,bin,[],[],lb,ub);
        sol_DROb{i_eps}(i_simu,:) = sol(1:n);
        obj_DROb(i_simu,i_eps) = fval;        
    end
    
    %% DROc
    xi_hat_matrix = reshape( xi_hat_vec, m, N )';    
    
    Ain_RSA = [
        ones(1,n) zeros(1,n_var_RSA - n);
        zeros(K,n) -ones(K,1) zeros(K,size_z+size_y+size_y_prime+size_w) gam_matrix zeros(K,size_f) -eye(K) zeros(K,size_h);
        zeros(size_z,n) zeros(size_z,size_r) -eye(size_z) zeros(size_z,size_y+size_y_prime) (1/N)*kron(eye(num_gam),xi_hat_matrix) -(1/N)*kron(eye(num_gam),ones(N,1)) zeros(size_z, size_f+size_g+size_h);
        zeros(size_w,n) zeros(size_w,size_r+size_z) -eye(size_y) zeros(size_y,size_y_prime) eye(size_w) zeros(size_w,size_w_prime+size_g+size_f+size_h);
        zeros(size_w,n) zeros(size_w,size_r+size_z) -eye(size_y) zeros(size_y,size_y_prime) -eye(size_w) zeros(size_w,size_w_prime+size_g+size_f+size_h);
        zeros(size_w_prime,n) zeros(size_w_prime,size_r+size_z+size_y) -eye(size_y_prime) zeros(size_y_prime,size_w) eye(size_w_prime) zeros(size_w_prime,size_g+size_f+size_h);
        zeros(size_w_prime,n) zeros(size_w_prime,size_r+size_z+size_y) -eye(size_y_prime) zeros(size_y_prime,size_w) -eye(size_w_prime) zeros(size_w_prime,size_g+size_f+size_h);
        zeros(size_f,n) zeros(size_f,size_r+size_z) ones(size_f,size_y+size_y_prime) zeros(size_f,size_w+size_w_prime) -1 zeros(size_f,size_g+size_h);
        kron([-2.5*lam1 -3*lam2 -20*lam3],ones(size_Xi_V,1)) zeros(size_Xi_V*K,size_r+size_z+size_y+size_y_prime+size_w+size_w_prime+size_f) kron(eye(K),ones(size_Xi_V,1)) -kron(eye(K),Xi_V);
        ];
    bin_RSA = [
        cap
        zeros(K,1);
        zeros(size_z,1);
        zeros(2*size_w+2*size_w_prime,1);
        0;
        -kron(eye(K),Xi_V) * reshape([lam1'; lam2'],[],1) + 6000*kron(lam4,ones(size_Xi_V,1))
        ];    
    Aeq_RSA = [
        zeros(size_h, n + size_r+size_z+size_y+size_y_prime) kron(gam_matrix,eye(m)) zeros(size_h,size_w_prime+size_f+size_g) -eye(size_h);
        ];
    beq_RSA = zeros(size_h,1);
    lb_RSA = [
        zeros(n,1);
        -inf*ones(size_r,1);
        0*ones(size_z+size_y+size_y_prime+size_w+size_w_prime+size_f,1);
        -inf*ones(size_g+size_h,1)
        ];
    ub_RSA = [
        cap*ones(n,1);
        inf*ones(n_var_RSA-n, 1)
        ];
    for i_eps = 1 : n_eps
        f_RSA = [
            panting_cost_wheat; panting_cost_corn; panting_cost_sugar
            1;
            ones(size_z, 1);
            zeros(size_y, 1);
            zeros(size_y_prime, 1);
            zeros(size_w, 1);
            zeros(size_w_prime, 1);
            critic_set(i_eps);
            zeros(size_g, 1);
            zeros(size_h, 1)
            ];
        [ sol_RSA_dum, fval ] = cplexlp(f_RSA,Ain_RSA,bin_RSA,Aeq_RSA,beq_RSA,lb_RSA,ub_RSA);
        sol_DROc{i_eps}(i_simu,:) = sol_RSA_dum(1:n);
        obj_DROc(i_simu,i_eps) = fval;
    end
    
    %% Prop.
    n_var = 3 + N + 2;
    lb = [ zeros(n,1); -inf*ones(N+2,1) ];
    sol = zeros(n_var, K);
    fval = zeros(K,1);
    for i_eps = 1 : n_eps
        beta_pro = beta_set(i_eps);
        f = [ panting_cost_wheat; panting_cost_corn; panting_cost_sugar; 1/N*ones(N,1); sqrt(beta_pro/N); sqrt(beta_pro/N) ];
        for j = 1 : K
            Ain = [
                ones(1,3) zeros(1,N+2);
                -yield_wheat*kron(ones(N,1),lam1) -yield_corn*kron(ones(N,1),lam2) -yield_sugar*kron(ones(N,1),lam3) -kron(eye(N),ones(K,1)) zeros(N*K,2);
                -yield_wheat*lam1 -yield_corn*lam2 -yield_sugar*lam3 zeros(K,N) -ones(K,1) zeros(K,1);
                yield_wheat*lam1(j) yield_corn*lam2(j) yield_sugar*lam3(j) zeros(1,N) 0 -1
                ];
            bin = [
                cap;
                - kron(xi1_hat_vec, lam1) - kron(xi2_hat_vec, lam2) + 6000*kron(ones(N,1), lam4);
                - xi_u(1) * lam1 - xi_u(2) * lam2 + 6000 * lam4;
                xi_l(1) * lam1(j) + xi_l(2) * lam2(j) - 6000 * lam4(j);
                ];
            [ sol(:,j), fval(j,1) ] = cplexlp(f,Ain,bin,[],[],lb);            
        end
        [ ~, ind_sol ] = sort(fval,'descend');
        sol_pro_dum = sol(:,ind_sol(end));        
        sol_pro{i_eps}(i_simu,:) = sol_pro_dum(1:n);
        obj_pro(i_simu,i_eps) = fval(ind_sol(end));
        if obj_pro(i_simu,i_eps) > obj_RO
            sol_pro{i_eps}(i_simu,:) = sol_RO;
            obj_pro(i_simu,i_eps) = obj_RO;
        end
    end

    %% Expected cost

    % sample
    xi1_hat_oos_vec = random(pd{1}, n_eva, 1);
    xi2_hat_oos_vec = random(pd{2}, n_eva, 1);

    for i_oos = 1 : n_eva    
        % DROa
        for i_eps = 1 : n_eps
            bin_dum = B_dum * sol_DROa{i_eps}(i_simu,:)' + D_dum * [xi1_hat_oos_vec(i_oos); xi2_hat_oos_vec(i_oos)] + e_dum;
            [~, fval] = cplexlp(f_dum,Ain_dum,bin_dum,[],[],zeros(6,1));
            loss_DROa{i_eps}(i_simu,i_oos) = [ panting_cost_wheat; panting_cost_corn; panting_cost_sugar ]' * sol_DROa{i_eps}(i_simu,:)' + fval;
        end
        % DROb
        for i_eps = 1 : n_eps
            bin_dum = B_dum * sol_DROb{i_eps}(i_simu,:)' + D_dum * [xi1_hat_oos_vec(i_oos); xi2_hat_oos_vec(i_oos)] + e_dum;
            [~, fval] = cplexlp(f_dum,Ain_dum,bin_dum,[],[],zeros(6,1));
            loss_DROb{i_eps}(i_simu,i_oos) = [ panting_cost_wheat; panting_cost_corn; panting_cost_sugar ]' * sol_DROb{i_eps}(i_simu,:)' + fval;
        end
        % DROc
        for i_eps = 1 : n_eps
            bin_dum = B_dum * sol_DROc{i_eps}(i_simu,:)' + D_dum * [xi1_hat_oos_vec(i_oos); xi2_hat_oos_vec(i_oos)] + e_dum;
            [~, fval] = cplexlp(f_dum,Ain_dum,bin_dum,[],[],zeros(6,1));
            loss_DROc{i_eps}(i_simu,i_oos) = [ panting_cost_wheat; panting_cost_corn; panting_cost_sugar ]' * sol_DROc{i_eps}(i_simu,:)' + fval;
        end
        % Prop.
        for i_eps = 1 : n_eps
            bin_dum = B_dum * sol_pro{i_eps}(i_simu,:)' + D_dum * [xi1_hat_oos_vec(i_oos); xi2_hat_oos_vec(i_oos)] + e_dum;
            [~, fval] = cplexlp(f_dum,Ain_dum,bin_dum,[],[],zeros(6,1));
            loss_pro{i_eps}(i_simu,i_oos) = [ panting_cost_wheat; panting_cost_corn; panting_cost_sugar ]' * sol_pro{i_eps}(i_simu,:)' + fval;
        end        
    end
        
    for i_eps = 1 : n_eps
        oos_DROa(i_simu,i_eps) = mean(loss_DROa{i_eps}(i_simu,:));    
        oos_DROb(i_simu,i_eps) = mean(loss_DROb{i_eps}(i_simu,:));    
        oos_DROc(i_simu,i_eps) = mean(loss_DROc{i_eps}(i_simu,:));    
        oos_pro(i_simu,i_eps) = mean(loss_pro{i_eps}(i_simu,:));    
    end        
end

optimal_value_DROa = mean(obj_DROa);
optimal_value_DROb = mean(obj_DROb);
optimal_value_DROc = mean(obj_DROc);
optimal_value_pro = mean(obj_pro);

expected_cost_DROa = mean(oos_DROa);
expected_cost_DROb = mean(oos_DROb);
expected_cost_DROc = mean(oos_DROc);
expected_cost_pro = mean(oos_pro);
