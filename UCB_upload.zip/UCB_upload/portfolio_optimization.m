clear 

alpha = 0.2; 
rho = 10;
m = 10;
I_m = eye(m);
K = 2; 
a1 = -1; a2 = -1 -rho/alpha; a = [ a1; a2 ]; 
b1 = rho; b2 = rho * (1 - inv(alpha)); b = [ b1; b2 ]; 
N = 1e1; % sample size
N_simu = 1e3;
n_eva = 1e5;
xi_l = -1 * ones(m,1);
xi_u = 2 * ones(m,1);
C = [ eye(m); -eye(m) ]; 
d = [ xi_u; -xi_l ];
prob_set = .05:.05:.95; % confidence
n_eps = size(prob_set,2);
% DROa
diam_DROa = norm(xi_u - xi_l, 1);
epsilon_set_DROa = diam_DROa * sqrt( (2/N) * log(1./(1-prob_set)) );
% DROb
diam_DROb = norm(xi_u - xi_l, inf);
if 1 < m/2
    C_star = sqrt(m*2^(m - 2)) * (2 + 1/(1-2^(1 - 0.5*m)));
    epsilon_set_DROb = diam_DROb * ( C_star*N^(-1/m) + sqrt(2*m*log( 1./(1-prob_set) )/N) );
else
    C_star = sqrt(3 * 2) * (2 + 1/(1-2^(1-0.5*(3))));
    epsilon_set_DROb = diam_DROb * ( C_star*N^(-1/3) + sqrt(2*3*log( 1./(1-prob_set) )/N) );
end
% DROc
alpha_LCX = 1 - prob_set; 
Q_LCX = norm(xi_u,2)^2;
p_LCX =  0.5 * ( sqrt( log(256) + 8*log(N) + (log(2*N))^2) - log(2*N) ); 
critic_set = (1 + Q_LCX) * (2/(2-p_LCX)) * ((2^(1/2 + 1/p_LCX))/(N^(1 - 1/p_LCX))) * sqrt(m + 1 + (m+1) * log(N/(m+1)) + log(4./alpha_LCX));
% Prop.
beta_set = -0.5*log(1-prob_set);

obj_DROa = zeros(N_simu,n_eps);    
obj_DROb = zeros(N_simu,n_eps);
obj_DROc = zeros(N_simu,n_eps);
obj_pro = zeros(N_simu,n_eps);

x_DROa = cell(n_eps,1);
x_DROb = cell(n_eps,1);
x_DROc = cell(n_eps,1);
x_pro = cell(n_eps,1);

for i_eps = 1:n_eps
    x_DROa{i_eps} = zeros(N_simu,m);
    x_DROb{i_eps} = zeros(N_simu,m);
    x_DROc{i_eps} = zeros(N_simu,m);
    x_pro{i_eps} = zeros(N_simu,m);
end

tau_DROa = zeros(N_simu,n_eps);
tau_DROb = zeros(N_simu,n_eps);
tau_DROc = zeros(N_simu,n_eps);
tau_pro = zeros(N_simu,n_eps);

loss_DROa = cell(n_eps,1);
loss_DROb = cell(n_eps,1);
loss_DROc = cell(n_eps,1);
loss_pro = cell(n_eps,1);

for i_eps = 1:n_eps    
    loss_DROa{i_eps} = zeros(N_simu,n_eva);
    loss_DROb{i_eps} = zeros(N_simu,n_eva);
    loss_DROc{i_eps} = zeros(N_simu,n_eva);
    loss_pro{i_eps} = zeros(N_simu,n_eva);
end

oos_DROa = zeros(N_simu,n_eps);    
oos_DROb = zeros(N_simu,n_eps);    
oos_DROc = zeros(N_simu,n_eps);    
oos_pro = zeros(N_simu,n_eps);

%% distribution
dist_psi = makedist('Normal', 'mu', 0, 'sigma', 0.02);
dist_zeta = cell(m,1);
for i_asset = 1 : m
    dist_zeta{i_asset} = makedist('Normal', 'mu', 0.03*i_asset, 'sigma', 0.025*i_asset);
end

%% RO
n_var_RO = m + 1 + 1;
Ain = [
    kron(xi_l',a) b -ones(K,1);
    kron(xi_u',a) b -ones(K,1);
    ];
bin = [
    zeros(2*K,1);
    ];
Aeq = [ ones(1,m) zeros(1,n_var_RO-m) ];
beq = 1;
lb = [
    zeros(m,1); 
    -sum(xi_u);
    -inf 
    ];
ub = [
    inf * ones(m,1);
    -sum(xi_l);
    inf
    ];
f = [ 
    zeros(m+1,1); 
    1
    ];
[ sol, fval ] = cplexlp(f,Ain,bin,Aeq,beq,lb,ub);
x_RO = sol(1:m);
tau_RO = sol(m+1);    
obj_RO = fval;

for i_simu = 1 : N_simu
    
    % Sample
    xi_vector = zeros(N*m, 1);
    psi_vec = random(dist_psi, N, 1);
    for i_asset = 1 : m
        xi_vector = xi_vector + kron( random(dist_zeta{i_asset}, N, 1) + psi_vec , I_m(:, i_asset));
    end

    %% DROa,b  
    n_var_DRO = m + 1 + 1 + N + size(C,1)*N*K;
    xi_hat_matrix = reshape( xi_vector, m, N )';
    Aindum_gamma = - kron(ones(1,N*K),kron(xi_hat_matrix * C', ones(K,1))) .* kron( eye(N*K),ones(1,size(C,1)) ) + kron(eye(N*K),d');    
    Ain = [
        kron(xi_hat_matrix,a) kron(ones(N,1),b) zeros(N*K,1) -kron(eye(N),ones(K,1)) Aindum_gamma;
        kron(ones(N,1),kron(a,eye(m))) zeros(N*K*m,1) -ones(N*K*m,1) zeros(N*K*m,N) -kron(eye(N*K),C');
        -kron(ones(N,1),kron(a,eye(m))) zeros(N*K*m,1) -ones(N*K*m,1) zeros(N*K*m,N) kron(eye(N*K),C');
        ];
    bin = zeros(N*K + m*K*N*2,1);
    lb = [ 
        zeros(m,1); 
        -sum(xi_u);
        -inf*ones(n_var_DRO - m - 1 - size(C,1)*N*K,1); 
        zeros(size(C,1)*N*K,1) 
        ];
    ub = [
        inf * ones(m,1);
        -sum(xi_l);
        inf * ones(n_var_DRO - m - 1,1)
        ];
    Aeq = [ ones(1,m) zeros(1,n_var_DRO-m) ];
    beq = 1;

    % DROa
    for i_eps = 1 : n_eps
        tic
        epsilon = epsilon_set_DROa(i_eps);
        f = [ zeros(m,1); 0; epsilon; 1/N*ones(N,1); zeros(size(C,1)*N*K,1) ];
        [ sol, fval ] = cplexlp(f,Ain,bin,Aeq,beq,lb,ub);
        x_DROa{i_eps}(i_simu,:) = sol(1:m);
        tau_DROa(i_simu,i_eps) = sol(m+1);        
        obj_DROa(i_simu,i_eps) = fval;
    end
    
    % DROb
    for i_eps = 1 : n_eps
        epsilon = epsilon_set_DROb(i_eps);
        f = [ zeros(m,1); 0; epsilon; 1/N*ones(N,1); zeros(size(C,1)*N*K,1) ];
        [ sol, fval ] = cplexlp(f,Ain,bin,Aeq,beq,lb,ub);
        x_DROb{i_eps}(i_simu,:) = sol(1:m);
        tau_DROb(i_simu,i_eps) = sol(m+1);
        obj_DROb(i_simu,i_eps) = fval;
    end
    
    %% DROc   
    gam_matrix = dec2bin(0:2^K-1)' - '0';
    gam_matrix = gam_matrix(:,2:end);
    num_gam = size(gam_matrix,2);
    size_r = 1;
    size_z = num_gam*N;
    size_y = num_gam*m;
    size_y_prime = num_gam;
    size_w = num_gam*m;
    size_w_prime = num_gam;
    size_f = 1;
    size_g = K;
    size_h = K*m;
    n_var_RSA = m + 1 + size_r+size_z+size_y+size_y_prime+size_w+size_w_prime+size_f+size_g+size_h;
        
    Ain_RSA = [
        zeros(K,m+1) -ones(K,1) zeros(K,size_z+size_y+size_y_prime+size_w) gam_matrix zeros(K,size_f) -eye(K) zeros(K,size_h);
        zeros(size_z,m+1) zeros(size_z,size_r) -eye(size_z) zeros(size_z,size_y+size_y_prime) (1/N)*kron(eye(num_gam),xi_hat_matrix) -(1/N)*kron(eye(num_gam),ones(N,1)) zeros(size_z, size_f+size_g+size_h);
        zeros(size_w,m+1) zeros(size_w,size_r+size_z) -eye(size_y) zeros(size_y,size_y_prime) eye(size_w) zeros(size_w,size_w_prime+size_g+size_f+size_h);
        zeros(size_w,m+1) zeros(size_w,size_r+size_z) -eye(size_y) zeros(size_y,size_y_prime) -eye(size_w) zeros(size_w,size_w_prime+size_g+size_f+size_h);
        zeros(size_w_prime,m+1) zeros(size_w_prime,size_r+size_z+size_y) -eye(size_y_prime) zeros(size_y_prime,size_w) eye(size_w_prime) zeros(size_w_prime,size_g+size_f+size_h);
        zeros(size_w_prime,m+1) zeros(size_w_prime,size_r+size_z+size_y) -eye(size_y_prime) zeros(size_y_prime,size_w) -eye(size_w_prime) zeros(size_w_prime,size_g+size_f+size_h);
        zeros(size_f,m+1) zeros(size_f,size_r+size_z) ones(size_f,size_y+size_y_prime) zeros(size_f,size_w+size_w_prime) -1 zeros(size_f,size_g+size_h);
        a1*xi_l' b1 zeros(1,n_var_RSA-m-1-size_g-size_h) 1 0 -xi_l' zeros(1,m);
        a2*xi_l' b2 zeros(1,n_var_RSA-m-1-size_g-size_h) 0 1 zeros(1,m) -xi_l';
        ];

    bin_RSA = [
        zeros(K,1);
        zeros(size_z,1);
        zeros(2*size_w+2*size_w_prime,1);
        zeros(3,1);
        ];
    
    Aeq_RSA = [
        ones(1,m) zeros(1,n_var_RSA - m);
        zeros(size_h,m + 1 + size_r+size_z+size_y+size_y_prime) kron(gam_matrix,eye(m)) zeros(size_h,size_w_prime+size_f+size_g) -eye(size_h);
        ];

    beq_RSA = [
        1;
        zeros(size_h,1);
        ];
    lb_RSA = [
        zeros(m,1);
        -sum(xi_u);
        -inf*ones(size_r,1);
        0*ones(size_z+size_y+size_y_prime+size_w+size_w_prime+size_f,1);
        -inf*ones(size_g+size_h,1);
        ];
    ub_RSA = [
        ones(m,1);
        -sum(xi_l);
        inf*ones(n_var_RSA-m-1, 1);
        ];
    
    for i_eps = 1 : n_eps        
        f_RSA = [
            zeros(m,1);
            0;
            1;
            ones(size_z, 1);
            zeros(size_y, 1);
            zeros(size_y_prime, 1);
            zeros(size_w, 1);
            zeros(size_w_prime, 1);
            critic_set(i_eps);
            zeros(size_g, 1);
            zeros(size_h, 1)
            ];
        [ sol, fval ] = cplexlp(f_RSA,Ain_RSA,bin_RSA,Aeq_RSA,beq_RSA,lb_RSA,ub_RSA);
        x_DROc{i_eps}(i_simu,:) = sol(1:m);
        tau_DROc(i_simu,i_eps) = sol(m+1);
        obj_DROc(i_simu,i_eps) = fval;
    end
    
    %% Prop.
    n_var_pro = m + 1 + N + 1 + 1;
    bin = [
        zeros(N*K,1);
        zeros(K,1);
        0;
        ];
    Aeq = [ ones(1,m) zeros(1,n_var_pro-m) ];
    beq = 1;
    lb = [
        zeros(m,1); 
        -sum(xi_u);
        -inf*ones(N + 2,1); 
        ];
    ub = [
        inf*ones(m,1);
        -sum(xi_l);
        inf*ones(N+2,1);
        ];
    for i_eps = 1 : n_eps
        tic
        beta = beta_set(i_eps);
        f_pro = [
            zeros(m,1); 0; 1/N * ones(N,1); sqrt(beta/N)*ones(2,1)
            ];
        sol = zeros(n_var_pro, K);
        fval = zeros(K,1);
        %
        k = 1;
        Ain = [
            kron(xi_hat_matrix,a) kron(ones(N,1),b) -kron(eye(N),ones(K,1)) zeros(N*K,2);
            kron(xi_l',a) b zeros(K,N) -ones(K,1) zeros(K,1);
            -kron(xi_u',a(1)) -b(1) zeros(1,N + 1) -1;
            ];
        [ sol(:,k), fval(k) ] = cplexlp(f_pro,Ain,bin,Aeq,beq,lb,ub);
        %
        k = 2;
        Ain = [
            kron(xi_hat_matrix,a) kron(ones(N,1),b) -kron(eye(N),ones(K,1)) zeros(N*K,2);
            kron(xi_l',a) b zeros(K,N) -ones(K,1) zeros(K,1);
            -kron(xi_u',a(2)) -b(2) zeros(1,N + 1) -1;
            ];
        [ sol(:,k), fval(k) ] = cplexlp(f_pro,Ain,bin,Aeq,beq,lb,ub);
        
        [ ~, ind_sol ] = sort(fval,'descend');
        sol_pro_dum = sol(:,ind_sol(end));        
        x_pro{i_eps}(i_simu,:) = sol_pro_dum(1:m);
        tau_pro(i_simu,i_eps) = sol_pro_dum(m+1);
        obj_pro(i_simu,i_eps) = fval(ind_sol(end));
        if obj_pro(i_simu,i_eps) > obj_RO
            obj_pro(i_simu,i_eps) = obj_RO;
            x_pro{i_eps}(i_simu,:) = x_RO;
            tau_pro(i_simu,i_eps) = tau_RO;            
        end
    end
    
    %% Expected cost  
    for i_oos = 1 : n_eva       

        % Sample
        xi_hat_oos_vec = zeros(m,1);
        psi_vec_oos = random(dist_psi, 1, 1);
        for i_asset = 1 : m
            ttt = random(dist_zeta{i_asset},1,1) + psi_vec_oos;
            ttt = min(2,ttt);
            ttt = max(-1,ttt);
            xi_hat_oos_vec = xi_hat_oos_vec + kron( ttt , I_m(:, i_asset));
        end

        % DROa
        for i_eps = 1 : n_eps
            loss_DROa{i_eps}(i_simu,i_oos) = max(...
                a1*x_DROa{i_eps}(i_simu,:)*xi_hat_oos_vec + b1*tau_DROa(i_simu,i_eps), ...
                a2*x_DROa{i_eps}(i_simu,:)*xi_hat_oos_vec + b2*tau_DROa(i_simu,i_eps));
        end
        
        % DROb
        for i_eps = 1 : n_eps
            loss_DROb{i_eps}(i_simu,i_oos) = max(...
                a1*x_DROb{i_eps}(i_simu,:)*xi_hat_oos_vec + b1*tau_DROb(i_simu,i_eps), ...
                a2*x_DROb{i_eps}(i_simu,:)*xi_hat_oos_vec + b2*tau_DROb(i_simu,i_eps));
        end
        
        % DROc
        for i_eps = 1 : n_eps
            loss_DROc{i_eps}(i_simu,i_oos) = max(...
                a1*x_DROc{i_eps}(i_simu,:)*xi_hat_oos_vec + b1*tau_DROc(i_simu,i_eps), ...
                a2*x_DROc{i_eps}(i_simu,:)*xi_hat_oos_vec + b2*tau_DROc(i_simu,i_eps));
        end
        
        % Prop.
        for i_eps = 1 : n_eps
            loss_pro{i_eps}(i_simu,i_oos) = max(...
                a1*x_pro{i_eps}(i_simu,:)*xi_hat_oos_vec + b1*tau_pro(i_simu,i_eps), ...
                a2*x_pro{i_eps}(i_simu,:)*xi_hat_oos_vec + b2*tau_pro(i_simu,i_eps));
        end
    end
    
    for i_eps = 1 : n_eps
        oos_DROa(i_simu,i_eps) = mean(loss_DROa{i_eps}(i_simu,:));    
        oos_DROb(i_simu,i_eps) = mean(loss_DROb{i_eps}(i_simu,:));    
        oos_DROc(i_simu,i_eps) = mean(loss_DROc{i_eps}(i_simu,:));    
        oos_pro(i_simu,i_eps) = mean(loss_pro{i_eps}(i_simu,:));    
    end
end

optimal_value_DROa = mean(obj_DROa);
optimal_value_DROb = mean(obj_DROb);
optimal_value_DROc = mean(obj_DROc);
optimal_value_pro = mean(obj_pro);

expected_cost_DROa = mean(oos_DROa);
expected_cost_DROb = mean(oos_DROb);
expected_cost_DROc = mean(oos_DROc);
expected_cost_pro = mean(oos_pro);
